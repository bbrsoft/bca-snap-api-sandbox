<?php
// Endpoint untuk Mutasi Rekening
$url = "https://sandbox.bca.co.id/openapi/v1.0/bank-statement";

// Ambil Private Key dari file
$privateKey = file_get_contents('private_key.pem');
$privateKeyResource = openssl_pkey_get_private($privateKey);

// Data Request
$requestData = [
    "startDate" => "2024-12-01",
    "endDate" => "2024-12-02",
    "accountNumber" => "1234567890"
];
$payload = json_encode($requestData);

// Tanda Tangan dengan Private Key
if (!openssl_sign($payload, $signature, $privateKeyResource, OPENSSL_ALGO_SHA256)) {
    die("Error: Unable to sign payload with private key.");
}
$encodedSignature = base64_encode($signature);

// Data Header
$headers = [
    "Authorization: Bearer r82wOXsvzWhK789UA7K5SVbmHJXVRnD8daZK7W0zvZE9w2tJ0CsMW0",
    "Content-Type: application/json",
    "X-SIGNATURE: $encodedSignature",
    "X-Timestamp: " . gmdate("Y-m-d\TH:i:s\Z"),
    "CHANNEL-ID: your_channel_id",
    "X-PARTNER-ID: your_partner_id"
];

// Data Body
$body = json_encode($requestData);

// Inisialisasi cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);

// Eksekusi cURL dan mendapatkan respons
$response = curl_exec($ch);

// Periksa error cURL
if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
    curl_close($ch);
    exit;
}

// Tutup cURL
curl_close($ch);

// Tampilkan hasil respons
echo "Response: " . $response;
?>
