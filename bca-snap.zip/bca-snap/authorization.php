<?php
// Client ID dan Client Secret Anda
$client_id = "6217ee46-36f8-4d00-98f0-2e339cf0ddea";
$client_secret = "bc1e3be3-0e42-4848-806f-885f2c48efe9";

// Header untuk permintaan
echo base64_encode($client_id . ":" . $client_secret);