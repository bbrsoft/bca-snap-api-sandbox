<?php
// Endpoint OAuth untuk mendapatkan access token
$url = "https://sandbox.bca.co.id/api/oauth/token";

// Client ID dan Client Secret Anda
$client_id = "6217ee46-36f8-4d00-98f0-2e339cf0ddea";
$client_secret = "bc1e3be3-0e42-4848-806f-885f2c48efe9";

// Header untuk permintaan
$headers = [
    "Authorization: Basic " . base64_encode($client_id . ":" . $client_secret),
    "Content-Type: application/x-www-form-urlencoded"
];

// Data body untuk permintaan
$data = http_build_query([
    "grant_type" => "client_credentials"
]);

// Inisialisasi cURL
$ch = curl_init();

// Set opsi cURL
curl_setopt($ch, CURLOPT_URL, $url); // URL tujuan
curl_setopt($ch, CURLOPT_POST, true); // Metode POST
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Mendapatkan respons sebagai string
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); // Menambahkan header
curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // Menambahkan data body ke permintaan

// Eksekusi cURL dan mendapatkan respons
$response = curl_exec($ch);

// Periksa apakah ada error
if (curl_errno($ch)) {
    echo "cURL Error: " . curl_error($ch);
    curl_close($ch);
    exit;
}

// Tutup cURL
curl_close($ch);

// Decode respons JSON
$result = json_decode($response, true);

// Periksa apakah access_token tersedia
if (isset($result['access_token'])) {
    echo "Access Token: " . $result['access_token'] . "\n";
    echo "Token Type: " . $result['token_type'] . "\n";
    echo "Expires In: " . $result['expires_in'] . " seconds\n";
} else {
    // Tampilkan respons error jika access_token tidak ditemukan
    echo "Error: " . $response;
}
?>
