

<?php
// Code Berhasil
/**
 * author : bambang rahmat hidayat
 * call : +6285363644591
 * email : bbrsoftdream@gmail.com
 */
// Endpoint URL

$url = 'https://sandbox.bca.co.id/api/v1/utilities/signature-auth';

// Header values
$clientKey = '6217ee46-36f8-4d00-98f0-2e339cf0ddea'; // Ganti dengan X-CLIENT-KEY Anda
$privateKey = '-----BEGIN PRIVATE KEY----- MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCe5ktDYufsqjv8HH78fzloRa6DjuDMMD8YxVCc3uQYOPxN2IWb2cNs/pG3NnO6cfuqnEvUgvougsUMhVUVl1n670pA2B2eiOQdsYPNxZsSUVPHUjg1ZHSWn5yNxMZ9MIZv1DhZVzdiRMtAw66jTyF9BleCcjq/oW3uHqKWGtepOJVHNtgLz9MGJTzEXb0uEOOK0uCuJK+VMMqKXlUhMZur2Bah99D6vuMnmpmCnNQEvVj4MqhFQHD4uzW6qq2IevwHVbk8wPOq1HByftBQW/fowdtJKfSRaUf6dShHBrdcHDWlu+5TOB7LcbUY7oKFDk8NGdrHQiRaKlgLfU2BGHVVAgMBAAECggEAUseq4fo+1N6CzX6S8TveTmIu3j6rAfUIigERVAgSUEQvvOZWBLFXzAp7IzVs6O7Eq0ctghKR/3UE7tbvUoY8zCupRUrRc2vhW07FWYfel5ZizO4adkZVLrsMNhcTSNjk0JGAoZp8Meeg86Z97nok+hs5r62OyZJx0KGJFiX5wB/ziNwBlrc5asxGk4DhwGsSILrpi+3/xTdTeUu1kAnSREHSEgunGW+VFE/lGXiG8gd254m6MW8nRlaKnSODlZd3+YRKbbRUAaZ/GyTdwMZZrptn9H+ZSRMl0Z9sS0pe8LmJM5eqiCjqCLaxeJ/nEQeJm5x3L1JQpGsnGVfZjDZowQKBgQDrevLyjZzFFJisTMBV1pe+KQuP0hF9SJqgzOXeMMMxnM93kC4obimgAcmJmiHUnWWLt1UGyut96kUZIkdZg3rj/rBrk2uKrnyrgdbhEtPtfWGJFSItLfcZcTBr+VoGWqqKEMhMFcVqxFTA8sY3Xzv6vzcrPtGtX0Q9PEj1Qo9A2QKBgQCsvv89kz98PYl+qx2oHZEXQcyEeGI6ibfDq98EYpoYjcflNSpzQm/QHNtLQLiJ9t5TW1gi/cNry24FiJTADw4O/6k3wIbuAIm7HsjUVwJYoeTtn98Q2Ymsksv4yu7K/F8qXb6ELIlYlXOV19ZERcJLKbbQ2yl88Ww7+i0reu0K3QKBgAn/45c3OkQINt+CNtyuSy1REuOdmQ6H6cEQUmaYDYHq1ciO/9bJrszTpppISE1+DZTcSSkLrupe62ZA1WTQt4Q9CYLX9MYj2Llzvws5wHQiUeT/V78xZ3/WFadQJGmGqh1Izyij+Akroym6ZX5udd6VBiO4/DBvjjdHexWnKOwpAoGBAJ5/0OnKhWGVhOa4UsnB9zKDqQeS/W4Alp/uvv3jCsikrljcY0rGFpm5IGz3wVq1LGEHWuMgO4JYcWaaXwGpzphsc/M3r5YI4FbUdCiAfSKdyNNO8Pkg4HV7a7OnX1rYHOlegkP8KTkiR5+hHnQeHZuhdqBDttlxGoIdlfxjGcPxAoGBALSkWh2WzX+rt5Q8jA2nPoj01Je2KXt1NkwWVddaYhI4M65Wsdi2qvi5nradXzOs2p2E/VuoJ0nDotPPxrzdygZ3at0teyGlYEAnfIJPacA3G9FD73smM/2CkVAbaMVt6kNZuVFypnEhMbf6A8SKbH0/N4QBo0GBAXH7OmA0hkSp -----END PRIVATE KEY-----'; // Ganti dengan Private_Key Anda

// Timestamp dalam format ISO-8601 (UTC)
$timestamp = new DateTime("now", new DateTimeZone("Asia/Jakarta"));
$timestampFormatted = $timestamp->format('Y-m-d\TH:i:sP');

// Header permintaan
$headers = [
    'X-CLIENT-KEY: ' . $clientKey,
    'X-TIMESTAMP: ' . $timestampFormatted,
    'Private_Key: ' . $privateKey,
    'Content-Type: application/json',
];

// Inisialisasi cURL
$ch = curl_init($url);

// Atur opsi cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);

// Kirim permintaan dan ambil respons
$response = curl_exec($ch);

// Periksa jika ada kesalahan pada cURL
if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    // Decode JSON response
    $responseData = json_decode($response, true);
    echo "Response: " . print_r($responseData, true);
}

// Tutup cURL
curl_close($ch);
?>
