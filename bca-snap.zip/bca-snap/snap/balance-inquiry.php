

<?php
// Code Berhasil
/**
 * author : bambang rahmat hidayat
 * call : +6285363644591
 * email : bbrsoftdream@gmail.com
 */
// Endpoint URL

$url = 'https://sandbox.bca.co.id/api/v1/utilities/signature-auth';

// Header values
$clientKey = '6217ee46-36f8-4d00-98f0-2e339cf0ddea'; // Ganti dengan X-CLIENT-KEY Anda
$privateKey = '-----BEGIN PRIVATE KEY----- MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCe5ktDYufsqjv8HH78fzloRa6DjuDMMD8YxVCc3uQYOPxN2IWb2cNs/pG3NnO6cfuqnEvUgvougsUMhVUVl1n670pA2B2eiOQdsYPNxZsSUVPHUjg1ZHSWn5yNxMZ9MIZv1DhZVzdiRMtAw66jTyF9BleCcjq/oW3uHqKWGtepOJVHNtgLz9MGJTzEXb0uEOOK0uCuJK+VMMqKXlUhMZur2Bah99D6vuMnmpmCnNQEvVj4MqhFQHD4uzW6qq2IevwHVbk8wPOq1HByftBQW/fowdtJKfSRaUf6dShHBrdcHDWlu+5TOB7LcbUY7oKFDk8NGdrHQiRaKlgLfU2BGHVVAgMBAAECggEAUseq4fo+1N6CzX6S8TveTmIu3j6rAfUIigERVAgSUEQvvOZWBLFXzAp7IzVs6O7Eq0ctghKR/3UE7tbvUoY8zCupRUrRc2vhW07FWYfel5ZizO4adkZVLrsMNhcTSNjk0JGAoZp8Meeg86Z97nok+hs5r62OyZJx0KGJFiX5wB/ziNwBlrc5asxGk4DhwGsSILrpi+3/xTdTeUu1kAnSREHSEgunGW+VFE/lGXiG8gd254m6MW8nRlaKnSODlZd3+YRKbbRUAaZ/GyTdwMZZrptn9H+ZSRMl0Z9sS0pe8LmJM5eqiCjqCLaxeJ/nEQeJm5x3L1JQpGsnGVfZjDZowQKBgQDrevLyjZzFFJisTMBV1pe+KQuP0hF9SJqgzOXeMMMxnM93kC4obimgAcmJmiHUnWWLt1UGyut96kUZIkdZg3rj/rBrk2uKrnyrgdbhEtPtfWGJFSItLfcZcTBr+VoGWqqKEMhMFcVqxFTA8sY3Xzv6vzcrPtGtX0Q9PEj1Qo9A2QKBgQCsvv89kz98PYl+qx2oHZEXQcyEeGI6ibfDq98EYpoYjcflNSpzQm/QHNtLQLiJ9t5TW1gi/cNry24FiJTADw4O/6k3wIbuAIm7HsjUVwJYoeTtn98Q2Ymsksv4yu7K/F8qXb6ELIlYlXOV19ZERcJLKbbQ2yl88Ww7+i0reu0K3QKBgAn/45c3OkQINt+CNtyuSy1REuOdmQ6H6cEQUmaYDYHq1ciO/9bJrszTpppISE1+DZTcSSkLrupe62ZA1WTQt4Q9CYLX9MYj2Llzvws5wHQiUeT/V78xZ3/WFadQJGmGqh1Izyij+Akroym6ZX5udd6VBiO4/DBvjjdHexWnKOwpAoGBAJ5/0OnKhWGVhOa4UsnB9zKDqQeS/W4Alp/uvv3jCsikrljcY0rGFpm5IGz3wVq1LGEHWuMgO4JYcWaaXwGpzphsc/M3r5YI4FbUdCiAfSKdyNNO8Pkg4HV7a7OnX1rYHOlegkP8KTkiR5+hHnQeHZuhdqBDttlxGoIdlfxjGcPxAoGBALSkWh2WzX+rt5Q8jA2nPoj01Je2KXt1NkwWVddaYhI4M65Wsdi2qvi5nradXzOs2p2E/VuoJ0nDotPPxrzdygZ3at0teyGlYEAnfIJPacA3G9FD73smM/2CkVAbaMVt6kNZuVFypnEhMbf6A8SKbH0/N4QBo0GBAXH7OmA0hkSp -----END PRIVATE KEY-----'; // Ganti dengan Private_Key Anda

// Timestamp dalam format ISO-8601 (UTC)
$timestamp = new DateTime("now", new DateTimeZone("Asia/Jakarta"));
$timestampFormatted = $timestamp->format('Y-m-d\TH:i:sP');

// Header permintaan
$headers = [
    'X-CLIENT-KEY: ' . $clientKey,
    'X-TIMESTAMP: ' . $timestampFormatted,
    'Private_Key: ' . $privateKey,
    'Content-Type: application/json',
];

// Inisialisasi cURL
$ch = curl_init($url);

// Atur opsi cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);

// Kirim permintaan dan ambil respons
$response = curl_exec($ch);

// Periksa jika ada kesalahan pada cURL
if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    // Decode JSON response
    $responseData = json_decode($response, true);
    echo "Response1: " . print_r($responseData, true);
}

// Tutup cURL
curl_close($ch);
?>

<?php
// Endpoint URL
$url2 = 'https://sandbox.bca.co.id/openapi/v1.0/access-token/b2b';


// Body permintaan
$requestBody = json_encode([
    'grantType' => 'client_credentials',
]);


// Membuat signature menggunakan HMAC-SHA512
$signature = $responseData['signature'];

// Header permintaan
$headers2 = [
    'X-TIMESTAMP: '. $timestampFormatted,
    'X-CLIENT-KEY: ' . $clientKey,
    'X-SIGNATURE: ' . $signature,
    'Content-Type: application/json',
];

// Inisialisasi cURL
$ch2 = curl_init($url2);

// Atur opsi cURL
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_HTTPHEADER, $headers2);
curl_setopt($ch2, CURLOPT_POST, true);
curl_setopt($ch2, CURLOPT_POSTFIELDS, $requestBody);

// Kirim permintaan dan ambil respons
$response2 = curl_exec($ch2);

// Periksa jika ada kesalahan pada cURL
if ($response2 === false) {
    echo "cURL Error: " . curl_error($ch2);
} else {
    // Tampilkan respons API
    $response2Array = json_decode($response2, true);
    echo "Response2: " . print_r($response2Array, true);
}

// Tutup koneksi cURL
curl_close($ch2);
?>

<?php
// Endpoint URL
$url3 = 'https://sandbox.bca.co.id/api/v1/utilities/signature-service';
$partnerReferenceNo = rand(100000000000,9999999999999);
$accountNo = '0613008761';
// Access token (didapatkan dari langkah sebelumnya)
$accessToken = $response2Array['accessToken']; // Ganti dengan token Anda
$clientSecret ='bc1e3be3-0e42-4848-806f-885f2c48efe9';
// Data untuk permintaan
$requestBody3 = json_encode([
    "partnerReferenceNo" => $partnerReferenceNo,
    "accountNo" => $accountNo,
    "fromDateTime" => "2021-12-05T00:00:00+07:00",
    "toDateTime" => "2021-12-06T00:00:00+07:00"
]);


$headers3 = [
    "X-TIMESTAMP: $timestampFormatted",
    "accesstoken: $accessToken",
    "EndpoinUrl: /openapi/v1.0/balance-inquiry",
    "X-CLIENT-SECRET: ".$clientSecret, // Ganti dengan secret Anda
    "HttpMethod: POST",
    "Content-Type: application/json"
];

// Inisialisasi cURL
$ch3 = curl_init($url3);
curl_setopt($ch3, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch3, CURLOPT_HTTPHEADER, $headers3);
curl_setopt($ch3, CURLOPT_POST, true);
curl_setopt($ch3, CURLOPT_POSTFIELDS, $requestBody3);

// Eksekusi cURL
$response3 = curl_exec($ch3);
if ($response3 === false) {
    echo "cURL Error: " . curl_error($ch3);
} else {
    $response3Array = json_decode($response3, true);
    echo "Response3: " . print_r($response3Array, true);
}
curl_close($ch3);
?>
<?php
// URL endpoint
$url4 = "https://sandbox.bca.co.id/openapi/v1.0/balance-inquiry";
$PARTNERID = 'h2hauto016';
$CHANNELID = '95051';
// Header untuk permintaan
$headers4 = [
    "X-PARTNER-ID: ".$PARTNERID, // Ganti dengan Partner ID Anda
    "Authorization: Bearer ".$response2Array['accessToken'], // Ganti dengan Access Token yang valid
    "X-TIMESTAMP: " . $timestampFormatted, // Timestamp format UTC
    "CHANNEL-ID: ".$CHANNELID, // Ganti dengan Channel ID Anda
    "X-SIGNATURE: ".$response3Array['signature'], // Ganti dengan Signature yang valid
    "Content-Type: application/json"
];

// Data body request
$body4 = [
    "partnerReferenceNo" => $partnerReferenceNo, // Nomor referensi unik
    "accountNo" => $accountNo, // Nomor akun yang ingin dicek
    "fromDateTime" => "2021-12-05T00:00:00+07:00",
    "toDateTime" => "2021-12-06T00:00:00+07:00" // Waktu akhir (format ISO 8601)
];

// Konversi body ke JSON
$jsonBody4 = json_encode($body4);

// cURL setup
$ch4 = curl_init();
curl_setopt($ch4, CURLOPT_URL, $url4);
curl_setopt($ch4, CURLOPT_POST, true);
curl_setopt($ch4, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch4, CURLOPT_HTTPHEADER, $headers4);
curl_setopt($ch4, CURLOPT_POSTFIELDS, $jsonBody4);

// Eksekusi cURL
$response4 = curl_exec($ch4);

// Error handling
if (curl_errno($ch4)) {
    echo "cURL Error: " . curl_error($ch4);
} else {
    $response4Array = json_decode($response4, true);
    echo "Response4: " . print_r($response4Array, true);
}

// Tutup cURL
curl_close($ch4);
?>
