<?php
// Konfigurasi API
$partnerId = 'YOUR_PARTNER_ID'; // Ganti dengan X-PARTNER-ID Anda
$channelId = 'YOUR_CHANNEL_ID'; // Ganti dengan CHANNEL-ID Anda
$accessToken = 'Bearer cKorT72N4NBojFZ4rsDtY8RNSiaH4KrogVhEJHR8aytjuJGxw0YS3X'; // Ganti dengan Access Token Anda
$apiSecret = '429dfd80-5d38-46f9-86b0-6a9bc9bde5bf'; // Ganti dengan API Secret Anda
$uri = '/openapi/v1.0/balance-inquiry'; // Endpoint API
$httpMethod = 'POST';

// Membuat timestamp dalam format ISO8601
$timestamp = new DateTime("now", new DateTimeZone("Asia/Jakarta"));
$timestampFormatted = $timestamp->format('Y-m-d\TH:i:s.vP');

// Membuat payload body
$requestPayload = json_encode([
    // Sesuaikan isi body jika diperlukan
    "accountNumber" => "3080206835"
]);

// Hash payload
$hashedRequestPayload = hash('sha256', $requestPayload);

// Membuat string untuk signature
$dataToSign = $httpMethod . ':' . $uri . ':' . $timestampFormatted . ':' . $accessToken . ':' . $hashedRequestPayload;

// Membuat signature menggunakan HMAC-SHA256
$signature = hash_hmac('sha256', $dataToSign, $apiSecret);

// Headers
$headers = [
    'X-PARTNER-ID: ' . $partnerId,
    'Authorization: ' . $accessToken,
    'X-TIMESTAMP: ' . $timestampFormatted,
    'CHANNEL-ID: ' . $channelId,
    'X-SIGNATURE: ' . $signature,
    'Content-Type: application/json'
];

// Inisialisasi cURL
$ch = curl_init('https://sandbox.bca.co.id' . $uri);

// Mengatur opsi cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestPayload);

// Mengirimkan permintaan dan menangkap respons
$response = curl_exec($ch);

// Memeriksa error
if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    // Menampilkan respons
    echo "Response: " . $response;
}

// Menutup koneksi cURL
curl_close($ch);
?>
