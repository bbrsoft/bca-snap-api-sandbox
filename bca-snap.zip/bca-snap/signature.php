<?php
// Data API
$partnerId = 'H2HAUTO016'; 
$apiSecret = '429dfd80-5d38-46f9-86b0-6a9bc9bde5bf'; 
$channelId = '95051'; 
$accessToken = 'cTDz4u2QZzT952uBHHBjoWD7nM9vzz7Kt2eYFheHv0AuaHCfcuhqpO'; 

$timestamp = new DateTime("now", new DateTimeZone("Asia/Jakarta"));
$timestampFormatted = $timestamp->format('Y-m-d\TH:i:sP');

// Relative URL
$relativeUrl = 'https://sandbox.bca.co.id/openapi/v1.0/balance-inquiry';

// Request body (empty array encoded as JSON)
$requestBody = json_encode([]);  // Modified here to send valid JSON
$hashedBody = hash('sha256', $requestBody);

// Generate signature
$stringToSign = "POST:https://sandbox.bca.co.id/openapi/v1.0/balance-inquiry:" . $accessToken . ":" . $hashedBody . ":" . $timestampFormatted;
$signature = base64_encode(hash_hmac('sha512', $stringToSign, $apiSecret, true));

// Header permintaan
$headers = [
    'X-PARTNER-ID: ' . $partnerId,
    'Authorization: Bearer ' . $accessToken,
    'X-TIMESTAMP: ' . $timestampFormatted,
    'CHANNEL-ID: ' . $channelId,
    'X-SIGNATURE: ' . $signature,
    'Content-Type: application/json',  // Changed to application/json
];

// Inisialisasi cURL
$ch = curl_init($relativeUrl);

// Mengatur opsi cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);

// Mengirimkan permintaan dan menangkap respons
$response = curl_exec($ch);

// Memeriksa jika ada error
if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    var_dump($response);  // Debugging response
}

// Menutup koneksi cURL
curl_close($ch);
?>
