<?php
// Endpoint URL
$url = 'https://www.copartners.com/bca/async/statement';

// Header Signature
$passSignature = '4ead67878a6090b2a4bc43bb7c22a25490446a5180bc9e8b16e98d2639336912';

// Body JSON
$requestData = [
    'RequestID' => 'h2hauto014_0000000551',
    'AccountNumber' => '0613004197',
    'StartDate' => '2019-02-20',
    'EndDate' => '2019-02-20',
];
$requestBody = json_encode($requestData);

// Headers
$headers = [
    'Content-Type: application/json',
    'X-Pass-Signature: ' . $passSignature,
];

// Inisialisasi cURL
$ch = curl_init($url);

// Atur opsi cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

// Eksekusi permintaan
$response = curl_exec($ch);

// Periksa kesalahan cURL
if ($response === false) {
    echo 'cURL Error: ' . curl_error($ch);
} else {
    // Tampilkan respons
    echo 'Response: ' . $response;
}

// Tutup cURL
curl_close($ch);
?>
