<?php

// Kredensial API
$clientId = '6217ee46-36f8-4d00-98f0-2e339cf0ddea';         // Ganti dengan client_id Anda
$clientSecret = 'bc1e3be3-0e42-4848-806f-885f2c48efe9'; // Ganti dengan client_secret Anda

// Timestamp dalam format ISO 8601 (UTC)
// Timestamp dalam format ISO 8601 (UTC+7 untuk Jakarta)
$timestamp = new DateTime("now", new DateTimeZone("Asia/Jakarta"));
$timestampFormatted = $timestamp->format('Y-m-d\TH:i:sP'); // Format yang benar

// Tampilkan hasil timestamp untuk verifikasi
echo "Timestamp: " . $timestampFormatted . "\n";

// Endpoint URL untuk mendapatkan token
$tokenUrl = 'https://sandbox.bca.co.id/openapi/v1.0/access-token/b2b';

// Body permintaan (JSON)
$requestBody = json_encode([
    'grantType' => 'client_credentials'
]);

// Hash body permintaan dengan SHA256
$hashedBody = hash('sha256', $requestBody);

// String untuk signature
$stringToSign = "POST:$tokenUrl:$clientId:$hashedBody:$timestampFormatted";

// Debugging: Tampilkan string yang akan ditandatangani
echo "String to sign: $stringToSign\n";

// Generate signature menggunakan HMAC-SHA512
$signature = base64_encode(hash_hmac('sha512', $stringToSign, $clientSecret, true));

// Debugging: Tampilkan signature yang dihasilkan
echo "Generated Signature: $signature\n";

// Menyiapkan header permintaan
$headers = [
    'X-TIMESTAMP: ' . $timestampFormatted,
    'X-CLIENT-KEY: ' . $clientId,
    'X-SIGNATURE: ' . $signature,
    'Content-Type: application/json',
];

// Inisialisasi cURL
$ch = curl_init($tokenUrl);

// Mengatur opsi cURL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestBody);

// Kirim permintaan dan ambil respons
$response = curl_exec($ch);

// Cek jika ada error pada cURL
if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    // Decode JSON response
    $responseData = json_decode($response, true);

    if ($responseData['responseCode'] == '2007300') {
        // Sukses, dapatkan accessToken
        echo "Access Token: " . $responseData['accessToken'] . "\n";
    } else {
        // Jika gagal, tampilkan pesan kesalahan
        echo "Error: " . $responseData['responseMessage'] . "\n";
    }
}

// Menutup koneksi cURL
curl_close($ch);
?>
